#import "b8RootViewController.h"
#import <AVKit/AVKit.h>

@interface b8RootViewController () <UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) NSArray *channels;
@end

@implementation b8RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.title = @"Sport TV";

    // تحديث الصور لتكون محلية
    self.channels = @[
        @{
            @"name": @"beIN Sports 1",
            @"image": @"defaultImage", // صورة محلية باسم defaultImage
            @"url": @"https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8"
        },
        @{
            @"name": @"SSC Sports 1",
            @"image": @"defaultImage", // صورة محلية
            @"url": @"https://test-streams.mux.dev/test_001/stream.m3u8"
        },
        @{
            @"name": @"Sky Sports",
            @"image": @"defaultImage", // صورة محلية
            @"url": @"https://cph-p2p-msl.akamaized.net/hls/live/2000341/test/master.m3u8"
        },
        @{
            @"name": @"Al Kass Sports",
            @"image": @"defaultImage", // صورة محلية
            @"url": @"https://test-streams.mux.dev/pts/pts.m3u8"
        },
        @{
            @"name": @"AD Sports",
            @"image": @"defaultImage", // صورة محلية
            @"url": @"https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_ts/master.m3u8"
        }
    ];

    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];

    UILabel *footerLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 40)];
    footerLabel.text = @"© 2025 by Abdullah | @SportStream";
    footerLabel.textAlignment = NSTextAlignmentCenter;
    footerLabel.font = [UIFont systemFontOfSize:12];
    footerLabel.textColor = [UIColor grayColor];
    self.tableView.tableFooterView = footerLabel;
}

#pragma mark - TableView

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.channels.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellId = @"channelCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellId];
    }

    NSDictionary *channel = self.channels[indexPath.row];
    cell.textLabel.text = channel[@"name"];
    cell.detailTextLabel.text = channel[@"url"];

    // تحميل الصورة المحلية بدلاً من الإنترنت
    UIImage *image = [UIImage imageNamed:channel[@"image"]];
    if (image) {
        cell.imageView.image = image;
    } else {
        // إذا لم يتم العثور على الصورة، ضع صورة افتراضية أو فارغة
        cell.imageView.image = [UIImage imageNamed:@"defaultImage"];
    }
    
    cell.imageView.layer.cornerRadius = 8;
    cell.imageView.clipsToBounds = YES;

    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *channel = self.channels[indexPath.row];
    NSURL *url = [NSURL URLWithString:channel[@"url"]];
    AVPlayerViewController *playerVC = [[AVPlayerViewController alloc] init];
    playerVC.player = [AVPlayer playerWithURL:url];
    [self presentViewController:playerVC animated:YES completion:^{
        [playerVC.player play];
    }];
}

@end