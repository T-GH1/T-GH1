#import <Foundation/Foundation.h>
#import "b8AppDelegate.h"

int main(int argc, char *argv[]) {
	@autoreleasepool {
		return UIApplicationMain(argc, argv, nil, NSStringFromClass(b8AppDelegate.class));
	}
}
